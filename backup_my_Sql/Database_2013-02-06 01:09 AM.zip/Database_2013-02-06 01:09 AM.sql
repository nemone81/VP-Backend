#
# TABLE STRUCTURE FOR: abbonamenti
#

DROP TABLE IF EXISTS abbonamenti;

CREATE TABLE `abbonamenti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_socio` int(11) NOT NULL,
  `codice_abbonamento` varchar(11) NOT NULL,
  `scadenza` datetime NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `data_acquisto` date DEFAULT NULL,
  `data_creazione` datetime DEFAULT NULL,
  `data_modifica` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `delete` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (1, 4, 'SIN-2013', '2013-05-31 23:59:59', '', '', '2013-02-01', '2013-02-01 11:55:52', '2013-02-02 01:02:58', 1);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (2, 3, 'BIN-2013', '2013-12-31 23:59:59', '', '', '2013-02-02', '2013-02-02 12:18:03', '2013-02-05 19:15:42', 1);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (3, 3, 'BIN-2013', '2013-01-31 23:59:59', '', '', '2013-02-02', '2013-02-02 12:18:22', '2013-02-05 19:15:32', 1);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (4, 4, 'SIN-2013', '2013-01-31 23:59:59', '', '', '2013-02-02', '2013-02-02 12:22:13', '2013-02-02 12:22:13', 0);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (5, 4, 'SMN-2013', '2013-10-31 23:59:59', '', '', '2013-02-02', '2013-02-02 12:22:19', '2013-02-02 12:22:19', 0);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (6, 4, 'SIN-2013', '2013-09-30 23:59:59', '', '', '2013-02-02', '2013-02-02 12:22:36', '2013-02-02 12:22:36', 0);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (7, 4, 'SMN-2013', '2013-01-31 23:59:59', 'fdgsdf', '', '2013-02-02', '2013-02-02 10:10:16', '2013-02-02 10:10:16', 0);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (8, 1, 'SMN-2013', '2013-01-31 23:59:59', 'dsf', '', '2013-02-02', '2013-02-02 10:11:08', '2013-02-02 10:11:08', 0);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (9, 1, 'SMN-2013', '2013-01-31 23:59:59', 'dsf', '', '2013-02-02', '2013-02-02 10:12:18', '2013-02-02 10:12:18', 0);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (10, 2, 'BAN-2013', '2013-01-31 23:59:59', '', '', '2013-02-02', '2013-02-02 10:56:35', '2013-02-02 10:56:35', 0);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (11, 2, 'BMN-2013', '2013-10-31 23:59:59', '', '', '2013-02-02', '2013-02-02 11:00:18', '2013-02-05 19:12:44', 1);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (12, 2, 'BAN-2013', '2013-09-30 23:59:59', '', '', '2013-02-02', '2013-02-02 11:00:31', '2013-02-05 19:10:43', 1);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (13, 2, 'BTN-2013', '2013-11-30 23:59:59', '', '', '2013-02-02', '2013-02-02 11:00:56', '2013-02-05 19:13:19', 1);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (14, 3, 'UKC-2013', '2013-04-30 23:59:59', '', '', '2013-02-02', '2013-02-02 11:48:18', '2013-02-04 00:23:15', 1);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (15, 4, 'SMN-2013', '2013-01-31 23:59:59', '', '', '2013-02-27', '2013-02-03 10:08:43', '2013-02-03 10:08:43', 0);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (16, 4, 'SMN-2013', '2013-01-31 23:59:59', '', '', '2013-04-12', '2013-02-03 10:09:29', '2013-02-03 10:09:29', 0);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (17, 4, 'SMN-2013', '2013-01-31 23:59:59', 'fasdfdsa', '', '2014-02-01', '2013-02-04 04:58:50', '2013-02-04 04:58:50', 0);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (18, 3, 'UMN-2013', '2014-08-31 23:59:59', '', '', '2013-02-05', '2013-02-05 10:49:39', '2013-02-05 19:15:25', 1);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (19, 3, 'UMN-2013', '2013-01-31 23:59:59', '', '', '2014-04-27', '2013-02-05 10:50:15', '2013-02-05 19:15:59', 1);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (20, 5, 'SMN-2013', '2013-01-31 23:59:59', '', '', '2013-02-05', '2013-02-05 03:23:56', '2013-02-05 03:23:56', 0);
INSERT INTO abbonamenti (`id`, `id_socio`, `codice_abbonamento`, `scadenza`, `note`, `slug`, `data_acquisto`, `data_creazione`, `data_modifica`, `delete`) VALUES (21, 3, 'UMN-2013', '2013-01-31 23:59:59', 'dsads', '', '2013-02-05', '2013-02-05 06:16:04', '2013-02-05 06:16:04', 0);


#
# TABLE STRUCTURE FOR: soci
#

DROP TABLE IF EXISTS soci;

CREATE TABLE `soci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cognome` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `tipo` varchar(3) NOT NULL,
  `data_nascita` date NOT NULL,
  `luogo_nascita` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sesso` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `tessera` int(11) NOT NULL,
  `email` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `comune_residenza` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `indirizzo_residenza` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `certificato_medico` date NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `data_creazione` datetime DEFAULT NULL,
  `data_modifica` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO soci (`id`, `nome`, `cognome`, `tipo`, `data_nascita`, `luogo_nascita`, `sesso`, `tessera`, `email`, `telefono`, `comune_residenza`, `indirizzo_residenza`, `certificato_medico`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (1, 'Fabio', 'Crestoni', 'S', '1981-12-12', '', 'Maschio', 1, 'fabio.crestoni@gmail.com', '3451020970', '', 'Via g. a. pasquale, 49', '1901-01-17', 'sdad', 'id_1359732562-403922485', '2013-02-01 03:29:22', '2013-02-01 03:30:19');
INSERT INTO soci (`id`, `nome`, `cognome`, `tipo`, `data_nascita`, `luogo_nascita`, `sesso`, `tessera`, `email`, `telefono`, `comune_residenza`, `indirizzo_residenza`, `certificato_medico`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (2, 'Aled', 'Dsfads', 'B', '1981-12-12', '', 'Maschio', 2, '', 'dsfads', '', '', '2013-02-13', 'dsf  sdfsfdvsd  dfa ds fads f asdfads', 'id_1359732700-1125526872', '2013-02-01 03:31:40', '2013-02-01 05:07:25');
INSERT INTO soci (`id`, `nome`, `cognome`, `tipo`, `data_nascita`, `luogo_nascita`, `sesso`, `tessera`, `email`, `telefono`, `comune_residenza`, `indirizzo_residenza`, `certificato_medico`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (3, 'Lorenzi', 'Ferrara', 'U', '1980-01-19', 'Bn', 'Femmina', 3, 'lorenzoferrarajr@gmail.com', '123456789', 'Roma', 'Via Roma 30', '2014-03-02', 'note', 'id_1359738804-2076110548', '2013-02-01 05:13:24', '2013-02-03 11:20:23');
INSERT INTO soci (`id`, `nome`, `cognome`, `tipo`, `data_nascita`, `luogo_nascita`, `sesso`, `tessera`, `email`, `telefono`, `comune_residenza`, `indirizzo_residenza`, `certificato_medico`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (5, 'Fadsf', 'Slami', 'S', '1981-12-12', '', 'Maschio', 5, '', '', '', '', '0000-00-00', '', 'id_1360077200-23278676', '2013-02-05 03:13:20', '2013-02-05 03:13:20');


#
# TABLE STRUCTURE FOR: storico_abbonamenti
#

DROP TABLE IF EXISTS storico_abbonamenti;

CREATE TABLE `storico_abbonamenti` (
  `id` int(11) DEFAULT NULL,
  `tipologia` int(128) DEFAULT '0',
  `mese` int(10) DEFAULT '0',
  `totali` int(10) DEFAULT '0',
  `year` int(10) DEFAULT '0',
  `data_modifica` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tipo_abbonamenti
#

DROP TABLE IF EXISTS tipo_abbonamenti;

CREATE TABLE `tipo_abbonamenti` (
  `id` int(11) NOT NULL,
  `codice` varchar(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `nome` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `durata` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `costo` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `slug` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `data_creazione` datetime DEFAULT NULL,
  `data_modifica` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (1, 'SMN-2013', 'Standard - Mensile Senza Corso', '30', '60', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (2, 'SMC-2013', 'Standard - Mensile Con Corso', '30', '65', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (3, 'UMN-2013', 'Universitario - Mensile Senza Corso', '30', '55', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (4, 'UMC-2013', 'Universitario - Mensile Con Corso', '30', '60', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (5, 'BMN-2013', 'Bambino - Mensile Senza Corso', '30', '0', 'NON POSSIBLE', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (6, 'BMC-2013', 'Bambino - Mensile Con Corso', '30', '50', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (7, 'STN-2013', 'Standard - Trimestrale Senza Corso', '180', '165', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (8, 'STC-2013', 'Standard - Trimestrale Con Corso', '180', '180', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (9, 'UTN-2013', 'Universitario - Trimestrale Senza Corso', '180', '150', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (10, 'UTC-2013', 'Universitario - Trimestrale Con Corso', '180', '165', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (11, 'BTN-2013', 'Bambino - Trimestrale Senza Corso', '180', '0', 'NON POSSIBLE', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (12, 'BTC-2013', 'Bambino - Trimestrale Con Corso', '180', '140', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (13, 'SAN-2013', 'Standard - Annuale Senza Corso', '365', '460', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (14, 'SAC-2013', 'Standard - Annuale Con Corso', '365', '500', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (15, 'UAN-2013', 'Universitario - Annuale Senza Corso', '365', '415', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (16, 'UAC-2013', 'Universitario - Annuale Con Corso', '365', '450', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (17, 'BAN-2013', 'Bambino - Annuale Senza Corso', '365', '0', 'NON POSSIBLE', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (18, 'BAC-2013', 'Bambino - Annuale Con Corso', '365', '420', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (19, 'SIN-2013', 'Standard - Iscrizione Senza Corso', '365', '35', '', '', '2029-01-13 02:53:00', '2013-01-30 10:18:45');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (21, 'UIN-2013', 'Universitario - Iscrizione Senza Corso', '365', '35', '', '', '2029-01-13 02:53:00', '2013-02-05 16:08:54');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (23, 'BIN-2013', 'Bambino - Iscrizione Senza Corso', '365', '35', '', '', '2029-01-13 02:53:00', '2013-02-05 16:08:59');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (25, 'SKN-2013', 'Standard - Carnet Senza Corso', '365', '100', '', '', '2029-01-13 02:53:00', '2013-02-05 16:09:10');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (27, 'UKN-2013', 'Universitario - Carnet Senza Corso', '365', '100', 'NON POSSIBLE', '', '2029-01-13 02:53:00', '2013-02-05 16:08:11');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (30, 'BKC-2013', 'Bambino - Carnet Corso', '365', '100', 'NON POSSIBLE', '', '2029-01-13 02:53:00', '2013-02-05 16:10:14');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (20, 'SIC-2013', 'Standard - Iscrizione Corso', '365', '35', 'NON POSSIBLE', NULL, NULL, '2013-02-05 16:06:00');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (22, 'UIC-2013', 'Universitario - Iscrizione Corso', '365', '35', 'NON POSSIBLE', NULL, NULL, '2013-02-05 16:08:57');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (24, 'BIC-2013', 'Bambino - Iscrizione Corso', '365', '35', 'NON POSSIBLE', NULL, NULL, '2013-02-05 16:10:17');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (26, 'SKC-2013', 'Standard - Carnet Corso', '365', '100', 'NON POSSIBLE', NULL, NULL, '2013-02-05 16:09:12');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (28, 'UKC-2013', 'Universitario - Carnet Corso', '365', '100', 'NON POSSIBLE', NULL, NULL, '2013-02-05 16:08:53');
INSERT INTO tipo_abbonamenti (`id`, `codice`, `nome`, `durata`, `costo`, `note`, `slug`, `data_creazione`, `data_modifica`) VALUES (29, 'BKN-2013', 'Bambino - Carnet Senza Corso', '365', '100', 'NON POSSIBLE', NULL, NULL, '2013-02-05 16:09:53');


#
# TABLE STRUCTURE FOR: transaction
#

DROP TABLE IF EXISTS transaction;

CREATE TABLE `transaction` (
  `id` int(11) DEFAULT NULL,
  `trans_id` int(128) DEFAULT '0',
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email_address` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO users (`id`, `username`, `email_address`, `password`, `date_created`) VALUES (1, 'fabio', 'fabio.crestoni@gmail.com', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', '0000-00-00 00:00:00');


